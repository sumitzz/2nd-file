package com.example.demo.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.UserDAO;
import com.example.demo.model.UserDetails;


	@Service
	public class UserService {
		@Autowired
		UserDAO dao;
		
		public ArrayList<UserDetails> display() {
				return dao.displayUser();
				
					}

		public int addUser(UserDetails user) {
			// TODO Auto-generated method stub
			return (dao.addUser(user));
		}

		public boolean validate(String name, String password) {
			return dao.userLogin(name, password);
		}



	
	

}
