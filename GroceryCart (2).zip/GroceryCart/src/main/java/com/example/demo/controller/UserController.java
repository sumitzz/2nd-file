package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.UserDetails;
import com.example.demo.services.UserService;



@Controller
@ResponseBody
public class UserController {
	@Autowired
	UserService service;
	
	@PostMapping("/add")
	public String addUser (@RequestBody UserDetails user) {
		System.out.println("controller");
		int affectedRows = service.addUser(user);
		if(affectedRows==1)
		return "1 Row added";
		else
			return "No row added";
	}
	
	@GetMapping("/map")
public ModelAndView hello() {
		ModelAndView modelAndView =  new ModelAndView();
		modelAndView.setViewName("grocery");
		modelAndView.addObject("test", "hello");
		return modelAndView;
	}
	
	
	@GetMapping("/form")
	public ModelAndView page() {
			
			ModelAndView modelAndView = new ModelAndView();
			modelAndView.setViewName("login");			
			return modelAndView;		
		}
	@PostMapping("/login")
	public ModelAndView login ( UserDetails login) {
		ModelAndView modelAndView = new ModelAndView();
		boolean ans  = service.validate(login.getUsername(), login.getPassword()); 
		if(ans)
		{ 
			modelAndView.setViewName("grocery");	
		modelAndView.addObject("result", "VERIFIED");
		} 
		else
			{modelAndView.setViewName("login");
			modelAndView.addObject("result", "NOT VERIFIED");}
		
		
		return modelAndView;
		
	}  
	@GetMapping("/user")
public ModelAndView login(@RequestParam("name") String name,
		@RequestParam("pass") String password) {
		System.out.println("details : " + name +" "+ password);
		ModelAndView modelAndView = new ModelAndView();
		boolean ans  = service.validate(name, password); 
		if(ans)
		{ 
			modelAndView.setViewName("login");	
		modelAndView.addObject("result", "VERIFIED");
		} 
		else
			{modelAndView.setViewName("login");
			modelAndView.addObject("result", "NOT VERIFIED");}
		
		
		return modelAndView;
		
	}  
	
}