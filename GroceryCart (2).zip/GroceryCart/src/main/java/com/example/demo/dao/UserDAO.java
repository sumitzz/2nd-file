package com.example.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.example.demo.model.UserDetails;


@Repository
public class UserDAO {

		
		public static Connection connectToDB() {
	Connection connection = null;
			try {
				// STEP - 1 : Register the driver
				Class.forName("oracle.jdbc.driver.OracleDriver");

				// STEP - 2 Connecting with oracle database
				 connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system",
						"admin");
				return connection;
			}

			catch (ClassNotFoundException | SQLException e ) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			} 
		}



	 
	public int addUser(UserDetails user) {
		System.out.println(user);
		
		int affectedRows=0;
		// STEP-3 Create Statement
		try {
			Connection con = connectToDB();
			PreparedStatement stmt = con.prepareStatement("insert into user_tbl values(?,?,?,?,?,?)");
			stmt.setInt(1, user.getUserId());
			stmt.setString(2, user.getName());
			stmt.setString(3, user.getEmail());
			stmt.setString(4 , user.getPhNo());
			stmt.setString(5, user.getUsername());
			stmt.setString(6, user.getPassword());
			
			// step 4 - execute sql query 

			affectedRows = stmt.executeUpdate();
	 
		
			
			con.close();	
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return affectedRows;
		
	}

	public  ArrayList<UserDetails> displayUser() {
		ArrayList<UserDetails> userList =  new ArrayList<UserDetails>();
		try {
			Connection con = connectToDB();
			
			

	PreparedStatement stmt1 = connectToDB().prepareStatement("select * from user_tbl");
			  
		
			
			ResultSet rs=stmt1.executeQuery();  
			
			while(rs.next())  {
				UserDetails x = new UserDetails();
				int id = rs.getInt(1);
				String name = 	rs.getString(2);
				String email = rs.getString(3);
				String phno = rs.getString(4);
				String username  =rs.getString(5);
				String password  =rs.getString(6);
				
				
				
				
				
				x.setUserId(id);
				x.setName(name);
				x.setEmail(email);
				x.setPhNo(phno);
				x.setUsername(username);
				x.setPassword(password);
				
				
				userList.add(x);
			}
			con.close();
			
			
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
		return userList;
	}
	
	
	public static boolean userLogin(String username, String password) {
		boolean flag = false;
	
		
		try {
			Connection con = connectToDB();
			
			

	PreparedStatement stmt2 = con.prepareStatement("select * from user_tbl where username = ? and password = ?");
	stmt2.setString(1, username);
	stmt2.setString(2, password);
			  
		
			
			ResultSet rs=stmt2.executeQuery();  
			while(rs.next()) {
				
					flag =  true;
				}
				
			
			con.close();
	}
		
	
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			
			}
		return flag;

	}

}


